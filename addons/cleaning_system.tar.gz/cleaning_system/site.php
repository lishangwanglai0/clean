<?php
/**
 * 保洁服务PC端模块微站定义
 *
 * @author 终南山的浪子
 * @url http://bbs.we7.cc/
 */
defined('IN_IA') or exit('Access Denied');

class Cleaning_systemModuleSite extends WeModuleSite {

	public function doMobileDifferent() {
		//这个操作被定义用来呈现 功能封面
	}
	public function doWebNavigation() {
		//这个操作被定义用来呈现 管理中心导航菜单
	}

}